package com.ras.User_main.controller;
import com.ras.User_main.dto.LoginUserDto;
import com.ras.User_main.dto.VerifyUserDto;
import com.ras.User_main.dto.RegisterUserDto;
import com.ras.User_main.model.User;
import com.ras.User_main.responses.LoginResponse;
import com.ras.User_main.service.AuthenticationService;
import com.ras.User_main.service.jwtService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/auth")
@RestController
public class AuthenticationController {
    private final jwtService jwtservice;
    private final AuthenticationService authenticationService;

    public AuthenticationController(jwtService jwtservice, AuthenticationService authenticationService) {
        this.jwtservice = jwtservice;
        this.authenticationService = authenticationService;
    }
    @PostMapping("/signup")
    public ResponseEntity<User> register(@RequestBody RegisterUserDto registerUserDto) {
        User registeredUser = authenticationService.signup(registerUserDto);
        return ResponseEntity.ok(registeredUser);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> authenticate(@RequestBody LoginUserDto loginUserDto){
        User authenticatedUser = authenticationService.authenticate(loginUserDto);
        String jwtToken = jwtservice.generatedToken(authenticatedUser);
        LoginResponse loginResponse = new LoginResponse(jwtToken, jwtservice.getJwtExpirationTime());
        return ResponseEntity.ok(loginResponse);
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyUser(@RequestBody VerifyUserDto verifyUserDto) {
        try {
            authenticationService.verifyUser(verifyUserDto);
            return ResponseEntity.ok("Account verified successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/resend")
    public ResponseEntity<?> resendVerificationCode(@RequestParam String email) {
        try {
            authenticationService.resendVerificationCode(email);
            return ResponseEntity.ok("Verification code sent");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


}
